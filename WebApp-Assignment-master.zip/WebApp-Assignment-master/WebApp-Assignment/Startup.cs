﻿using Microsoft.Owin;
using Owin;
using WebApp_Assignment;

[assembly: OwinStartup(typeof(Startup))]

namespace WebApp_Assignment
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.MapSignalR();
        }
    }
}