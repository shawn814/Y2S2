﻿using System;
using System.Linq;
using System.Web;

namespace WebApp_Assignment
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            Session["temp_token"] = Security.Token();
            Response.Redirect("~/Home.aspx");
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            //Response.Redirect("Error.aspx?errmsg=Looks like there is an error!");
        }

        protected void Session_End(object sender, EventArgs e)
        {
            ConnetDataContext db = new ConnetDataContext();
            liveRoom lr = db.liveRooms.SingleOrDefault(x => x.seller_Id == Session["id"].ToString());

            if (lr != null)
            {
                var lp = db.liveProducts.Where(x => x.roomId == lr.id);
                db.liveProducts.DeleteAllOnSubmit(lp);
                db.liveRooms.DeleteOnSubmit(lr);
                db.SubmitChanges();
            }

            Session.RemoveAll();
        }

        protected void Application_End(object sender, EventArgs e)
        {
        }

        protected void Application_PostAuthenticateRequest(object sender, EventArgs e)
        {
            Security.ProcessRoles();
        }
    }
}