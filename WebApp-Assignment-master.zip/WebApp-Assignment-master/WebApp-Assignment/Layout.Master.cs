﻿using System;
using System.Web.UI;
using WebApp_Assignment.csFile;
using System.Linq;

namespace WebApp_Assignment
{
    public partial class Layout : MasterPage
    {
        private ConnetDataContext database = new ConnetDataContext();

        public static string CartNum = "0";
        protected void Page_Load(object sender, EventArgs e)
        {
            string redirectUrlI = "https://www.instagram.com/connetcompany/?hl=en";
            string redirectUrlF = "https://www.facebook.com/Connet-373967533356068";
            var fPath = MapPath("~/Images/fbIcon.png");
            var imgBarCodeF = QrCode.QrcodeGenerator(redirectUrlF, fPath);
            var IPath = MapPath("~/Images/instaIcon.jpg");
            var imgBarCodeI = QrCode.QrcodeGenerator(redirectUrlI, IPath);
            instaQr.Controls.Add(imgBarCodeI);
            fbQr.Controls.Add(imgBarCodeF);
            if (!string.IsNullOrEmpty(Session["role"] as string) || !string.IsNullOrEmpty(Session["id"] as string))
            {
                string id = Session["id"].ToString();
                if (Session["role"].ToString() == "Buyer")
                {
                    var q = (from c in database.Carts where c.Buyer_Id == id select c.Product_ID).Count();
                    CartNum = q.ToString();
                    if (CartNum == "0")
                    {
                        CartNum = "0";
                    }
                }
                else
                {
                    CartNum = "0";
                }
            }
            else
            {
                CartNum = "0";
            }
        }
    }
}