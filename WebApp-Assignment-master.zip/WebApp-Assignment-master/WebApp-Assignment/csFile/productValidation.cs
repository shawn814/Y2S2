﻿using System;

namespace WebApp_Assignment.Broadcaster
{
    public class productValidation
    {
        public static string pName(string name)
        {
            var pName = Security.ParseOutHTML(name);
            if (string.IsNullOrEmpty(pName))
                return "The name is empty";
            if (pName.Length > 50)
                return "Name cannot be exceed more than 50 character";
            return null;
        }

        public static string pPrice(string price)
        {
            var pPrice = Security.ParseOutHTML(price);
            decimal p;
            if (string.IsNullOrEmpty(pPrice))
                return "The price cannot be empty";
            if (!decimal.TryParse(pPrice, out p))
                return "Please enter the number";
            if (Convert.ToDecimal(pPrice) <= 0)
                return "Price cannot be zero or negative";
            return null;
        }

        public static string pQuantity(string quantity)
        {
            var pQuantity = Security.ParseOutHTML(quantity);
            int p;
            if (string.IsNullOrEmpty(pQuantity))
                return "The quantity cannot be empty";
            if (!int.TryParse(quantity, out p))
                return "Please enter the number";
            if (Convert.ToInt32(quantity) <= 0)
                return "Quantity cannot be zero or negative";
            if (Convert.ToInt32(quantity) > 100000)
                return "Quantity cannot exceed 100000";
            return null;
        }

        public static string pDesc(string desc)
        {
            var pDesc = Security.ParseOutHTML(desc);
            if (string.IsNullOrEmpty(desc) || desc.Length <= 0)
                return "Description cannot be empty";
            return null;
        }
    }
}