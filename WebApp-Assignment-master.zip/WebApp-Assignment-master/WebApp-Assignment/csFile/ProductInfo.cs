﻿namespace WebApp_Assignment.csFile
{
    public class ProductInfo
    {
        public ProductInfo(string id, string name, decimal price, int quantity, string desc, string sellerId)
        {
            this.id = id;
            this.name = name;
            this.price = price;
            this.quantity = quantity;
            this.desc = desc;
            this.sellerId = sellerId;
        }

        public string id { get; set; }
        public string name { get; set; }
        public decimal price { get; set; }
        public int quantity { get; set; }
        public string desc { get; set; }
        public string sellerId { get; set; }
    }
}