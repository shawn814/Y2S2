﻿using System;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace WebApp_Assignment.Authentication
{
    public class Validation
    {
        public static string usernameValidate(string username)
        {
            var fullname = Security.ParseOutHTML(username);
            var match = Regex.Match(fullname, @"^[A-Za-z ]*$");
            if (string.IsNullOrEmpty(fullname))
                return "Full name cannot be empty";
            if (!match.Success)
                return "Invalid full name";
            return null;
        }

        public static string emailValidate(string mail)
        {
            var email = Security.ParseOutHTML(mail);
            if (string.IsNullOrEmpty(email))
                return "Email is empty";
            if (!EmailValidate(email))
                return "Invalid format of email";
            return null;
        }

        public static bool EmailValidate(string emailadd)
        {
            try
            {
                var m = new MailAddress(emailadd);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        public static string passwordValidate(string pwd)
        {
            var password = Security.ParseOutHTML(pwd);
            var match = Regex.Match(password, @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,15}$");
            if (string.IsNullOrEmpty(pwd))
                return "Password is empty";
            if (password.Length < 8)
                return "Password must more than 8";
            if (password.Length > 50)
                return "Password must less than 50";
            if (!match.Success)
                return "The password must have at least one upper case, one lower case and one number";
            return null;
        }

        public static string phoneNumber(string num)
        {
            var phoneNumber = Security.ParseOutHTML(num);
            Match match1 = Regex.Match(phoneNumber, @"01\d{8,9}"), match2 = Regex.Match(num, @"^01\d-\d{7,8}$");
            if (string.IsNullOrEmpty(phoneNumber))
                return "Phone Number cannot be empty";
            if (match1.Success || match2.Success)
                return null;
            return "Invalid Phone Number";
        }
    }
}