﻿using System;
using System.Web.UI;

namespace WebApp_Assignment
{
    public partial class Error : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["errmsg"])) ErrorMsg.Text = Request.QueryString["errmsg"];
        }
    }
}