﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Staffcontrol
{
    public partial class SellerDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(Session["id"] as string) || string.IsNullOrEmpty(Session["role"] as string))
            {
                Response.Redirect("~/Error.aspx?errmsg=Please try again");
            }
            else
            {
                if (Session["role"].ToString() == "Staff")
                {
                    int count = 0;
                    foreach (GridViewRow row in gvSeller.Rows)
                    {
                        count++;
                    }
                    lblCount.Text = count + "record[s] are found";
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Please try again");
                }
            }

        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtName.Text))
            {
                Response.Redirect("~/Staffcontrol/SellerList.aspx?username=" + txtName.Text);
            }
            else
            {
                Response.Redirect("~/Staffcontrol/SellerList.aspx");

            }
        }
    }
}