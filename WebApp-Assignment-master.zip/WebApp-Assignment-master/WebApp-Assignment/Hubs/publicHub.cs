﻿using System;
using System.IO;
using System.Linq;
using Microsoft.AspNet.SignalR;

namespace WebApp_Assignment.Hubs
{
    public class publicHub : Hub
    {
        ConnetDataContext db = new ConnetDataContext();
        public void SendToAll(string roomid, string name, string message)
        {
            Clients.All.sendMessage(roomid, name, message);
        }

        public void Send(string name, string message)
        {
            // Call the broadcastMessage method to update clients.
            Clients.All.broadcastMessage(name, message);
        }

        public void ViewSend(string roomid, string views)
        {
            Clients.All.viewReceive(roomid, views);
        }

        public void BroadcastEnd()
        {
            Security.DeleteBroadcast();
        }

        public void search(string tempToken, string searchString)
        {
            var seller = db.Sellers.Where(x => x.username.Contains(searchString));
            Clients.All.searchResult(tempToken);
        }
    }
}