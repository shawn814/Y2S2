﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace WebApp_Assignment
{
    public partial class ShoppingCart : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();
        public string display;

        protected void Page_Load(object sender, EventArgs e)
        {
            var userId = "";
            if (!string.IsNullOrEmpty(Session["id"] as string) && Session["role"].ToString() == "Buyer")
            {
                userId = Session["id"].ToString();
            }
            else
            {
                if (!string.IsNullOrEmpty(Session["id"] as string))
                {
                    if (Session["role"].ToString() == "Admin" || Session["role"].ToString() == "Seller" || Session["role"].ToString() == "Staff")
                    {
                        Response.Redirect("~/Error.aspx?errmsg=You are not logged in Buyer.");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=You are not logged in.");
                }
            }
            int count = 0;
            foreach (GridViewRow ro in GridView1.Rows)
            {
                count++;
            }
            if (IsPostBack)
            {
                var index = 0;
                foreach (GridViewRow r in GridView1.Rows)
                {
                    var id = GridView1.DataKeys[index].Values[0].ToString();
                    var q = (TextBox)r.Cells[1].FindControl("txtQuantity");
                    var quantity = Convert.ToInt32(q.Text);

                    index++;
                    var query = from c in db.Carts
                                where c.Buyer_Id == userId
                                select c;
                    foreach (var c in query)
                        if (c.Product_ID == id)
                            c.Cart_Quantity = quantity;
                    db.SubmitChanges();
                    var lblTotal = (Label)r.Cells[4].FindControl("lblTotal");
                    var lblPrice = (Label)r.Cells[3].FindControl("lblPrice");
                    var total = Convert.ToDecimal(lblPrice.Text) * quantity;
                    lblTotal.Text = total.ToString();
                }

            }
            if (count == 0)
            {
                lblError.Text = "The shopping cart is empty";
                btnCheckout.Visible = false;
            }
        }

        protected void btnCheckout_Click(object sender, EventArgs e)
        {
            Session["checkout"] = "";
            var p = "";
            var index = 0;
            foreach (GridViewRow r in GridView1.Rows)
            {
                var chk = (CheckBox)r.Cells[0].FindControl("chkProduct");
                if (chk != null && chk.Checked)
                {
                    var id = GridView1.DataKeys[index].Values[1].ToString();
                    p += id;
                    p += ",";
                }

                index++;
            }
            if (string.IsNullOrEmpty(p))
            {
                lblError.Text = "Please select the product before checkout";
            }
            else
            {
                Session["checkout"] = p;
                Response.Redirect("~/Viewer/CheckOut.aspx");
            }
        }
    }
}