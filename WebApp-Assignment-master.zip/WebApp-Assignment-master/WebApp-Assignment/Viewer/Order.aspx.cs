﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Viewer
{
    public partial class myOrder : System.Web.UI.Page
    {
        ConnetDataContext db = new ConnetDataContext();
        string id = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack)
            {
                if( string.IsNullOrEmpty(Session["id"] as string) || string.IsNullOrEmpty(Session["role"] as string))
                {
                    if(Session["role"].ToString() != "Buyer")
                    {
                        Response.Redirect("~/Error.aspx?errmsg=Please login");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Please login");
                }
                
            }
        }
       
    }
}