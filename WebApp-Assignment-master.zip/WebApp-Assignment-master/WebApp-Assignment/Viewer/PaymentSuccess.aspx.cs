﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Viewer
{
    public partial class ProcessOrder : System.Web.UI.Page
    {

        ConnetDataContext db = new ConnetDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            string userId = "";
            string addId = "";
            decimal total = 0;
            string checkOut = "";
            
            if (string.IsNullOrEmpty(Session["id"] as string) || string.IsNullOrEmpty(Session["addId"] as string) || string.IsNullOrEmpty(Session["checkout"] as string))
            {
                Response.Redirect("~/Error.aspx?errmsg=Please contact our staff");
            }
            else
            {
                userId = Session["id"].ToString();
                addId = Session["addId"].ToString();
                total = Convert.ToDecimal(Session["total"]);
                checkOut = Session["checkout"].ToString();
                string[] cc = checkOut.Split(',');
                if (!Page.IsPostBack)
                {
                    string address = "";
                    processPayment(userId, total, address, cc, addId);
                    foreach (string s in cc)
                    {
                        Cart c = db.Carts.SingleOrDefault(
                            a => a.Buyer_Id == userId && a.Product_ID == s);
                        if (c != null)
                        {
                            Product p = db.Products.SingleOrDefault(
                                b => b.Id == c.Product_ID);
                            p.Quantity = p.Quantity - c.Cart_Quantity;
                            db.SubmitChanges();
                            db.Carts.DeleteOnSubmit(c);
                            db.SubmitChanges();
                        }
                    }
                    Session["checkout"] = "";
                    Session["addId"] = "";
                    Session["total"] = "";
                    Response.Redirect("~/Home.aspx");
                }
            }
        }
        public void processPayment(string id, decimal total, string address, string[] productID, string addressId) //UserId,address and productId which represent a
        {
            string orderId = "";
            bool repeatId = false;
            var time = DateTime.Now;
            DateTime now = DateTime.Now;

            {
                orderId = Security.autoId('O');
                var same = db.Orders.SingleOrDefault(
                    s => s.Id == id);
                if (same == null) repeatId = true;
            } while (repeatId == false) ;
            Order o = new Order
            {
                Id = orderId,
                Order_Date = now,
                Order_Status = "Order",
                Payment_Amount = total,
                Buyer_ID = id,
                AddressId = addressId
            };
            db.Orders.InsertOnSubmit(o);
            db.SubmitChanges();
            for (int i = 0; i < productID.Length - 1; i++)
            {
                Cart c = db.Carts.SingleOrDefault(
                   p => p.Product_ID == productID[i] && p.Buyer_Id == id);
                Order_Detail od = new Order_Detail
                {
                    Id = orderId,
                    Product_ID = c.Product_ID,
                    Quantity = c.Cart_Quantity
                };
                db.Order_Details.InsertOnSubmit(od);
                db.SubmitChanges();
            }


        }
    }
}