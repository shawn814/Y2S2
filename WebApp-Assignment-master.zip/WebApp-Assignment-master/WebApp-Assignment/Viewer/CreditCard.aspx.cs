﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Viewer
{
    public partial class CreditCard : System.Web.UI.Page
    {
        string[] cc;
        ConnetDataContext db = new ConnetDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(Session["checkout"] as string) || string.IsNullOrEmpty(Session["addId"] as string) || string.IsNullOrEmpty(Session["id"] as string))
            {
                Response.Redirect("~/Error.aspx?errmsg=Please try again");
            }
            else
            {
                string checkOut = Session["checkout"].ToString();
                cc = checkOut.Split(',');
                string total = Session["total"].ToString();
                totalAmount.Text = "Total: RM " + total;

            }
        }
        protected void cvCardNum_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string temp = Security.ParseOutHTML(txtCardNum.Text);
            string tm = temp.Replace(" ", string.Empty);
            bool verified = ValidateCardNumber(tm);
            if (string.IsNullOrEmpty(args.Value))
            {
                cvCardNum.ErrorMessage = "The credit card number is empty";
                args.IsValid = false;
            }
            else
            {
                if (!verified)
                {
                    cvCardNum.ErrorMessage = "The credit card number is invalid";
                    args.IsValid = false;
                }
            }
        }
        protected void cvCreditCardEpx_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string exp = Security.ParseOutHTML(txtExpDate.Text);
            if (string.IsNullOrEmpty(exp))
            {
                cvExpDate.ErrorMessage = "The expire data cannot be empty";
                args.IsValid = false;
            }

        }

        protected void cvCreditCardCvv_ServerValidate(object source, ServerValidateEventArgs args)
        {
            string cvv = Security.ParseOutHTML(txtCvv.Text);
            if (string.IsNullOrEmpty(cvv))
            {
                cvCvv.ErrorMessage = "CVV/CVC cannot be empty";
                args.IsValid = false;
            }
            else if (Convert.ToInt32(cvv) < 0)
            {
                cvCvv.ErrorMessage = "Invalid CVV/CVC";
                args.IsValid = false;
            }
        }
       

        private static bool ValidateCardNumber(string cardNumber)
        {
            try
            {
                // Array to contain individual numbers
                var CheckNumbers = new ArrayList();
                // So, get length of card
                var CardLength = cardNumber.Length;

                // Double the value of alternate digits, starting with the second digit
                // from the right, i.e. back to front.
                // Loop through starting at the end
                for (var i = CardLength - 2; i >= 0; i = i - 2)
                    // Now read the contents at each index, this
                    // can then be stored as an array of integers

                    // Double the number returned
                    CheckNumbers.Add(int.Parse(cardNumber[i].ToString()) * 2);

                var CheckSum = 0; // Will hold the total sum of all checksum digits

                // Second stage, add separate digits of all products
                for (var iCount = 0; iCount <= CheckNumbers.Count - 1; iCount++)
                {
                    var _count = 0; // will hold the sum of the digits

                    // determine if current number has more than one digit
                    if ((int)CheckNumbers[iCount] > 9)
                    {
                        var _numLength = ((int)CheckNumbers[iCount]).ToString().Length;
                        // add count to each digit
                        for (var x = 0; x < _numLength; x++)
                            _count = _count + int.Parse(
                                         ((int)CheckNumbers[iCount]).ToString()[x].ToString());
                    }
                    else
                    {
                        // single digit, just add it by itself
                        _count = (int)CheckNumbers[iCount];
                    }

                    CheckSum = CheckSum + _count; // add sum to the total sum
                }

                // Stage 3, add the unaffected digits
                // Add all the digits that we didn't double still starting from the
                // right but this time we'll start from the rightmost number with 
                // alternating digits
                var OriginalSum = 0;
                for (var y = CardLength - 1; y >= 0; y = y - 2)
                    OriginalSum = OriginalSum + int.Parse(cardNumber[y].ToString());

                // Perform the final calculation, if the sum Mod 10 results in 0 then
                // it's valid, otherwise its false.
                return (OriginalSum + CheckSum) % 10 == 0;
            }
            catch
            {
                return false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                Response.Redirect("~/Viewer/PaymentSuccess.aspx");
            }
        }
       
        
    }
}