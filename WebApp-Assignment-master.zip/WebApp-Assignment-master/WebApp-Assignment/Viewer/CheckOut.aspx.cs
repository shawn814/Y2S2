﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApp_Assignment.csFile;

namespace WebApp_Assignment.Viewer
{
    public partial class CheckOut : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();
        string name = "";
        string id = "";
        string checkOut = "";
        string[] cc;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Session["name"] as string) || !string.IsNullOrEmpty(Session["id"] as string) || !string.IsNullOrEmpty(Session["checkout"] as string))
            {

                name = Session["name"].ToString();
                id = Session["id"].ToString();
                checkOut = Session["checkout"].ToString();
                cc = checkOut.Split(',');

            }
            else
            {
                Response.Redirect("~/Error.aspx?errmsg=Please try again");
            }
            if (!Page.IsPostBack)
            {
                SetInitialRow();
                Session["addId"] = "";
            }
            
        }

        private void SetInitialRow()
        {

            DataTable dt = new DataTable();
            DataRow dr = null;
            dt.Columns.Add(new DataColumn("No", typeof(int)));
            dt.Columns.Add(new DataColumn("Product Name", typeof(string)));
            dt.Columns.Add(new DataColumn("Quantity", typeof(int)));
            dt.Columns.Add(new DataColumn("Price per Quantity", typeof(string)));
            dt.Columns.Add(new DataColumn("Subtotal", typeof(decimal)));

            decimal total = 0;
            int count = 1;

            foreach (string x in cc)
            {
                dr = dt.NewRow();
                Cart c = db.Carts.SingleOrDefault(
                    a => a.Product_ID == x && a.Buyer_Id == id);
                if (c != null)
                {
                    var p = db.Products.SingleOrDefault(
                        a => a.Id == x);
                    dr["No"] = count;
                    dr["Product Name"] = p.Name;
                    dr["Quantity"] = c.Cart_Quantity;
                    dr["Price per Quantity"] = p.Price.ToString();
                    decimal sub = Convert.ToDecimal(c.Cart_Quantity) * p.Price;
                    dr["Subtotal"] = sub;
                    dt.Rows.Add(dr);
                    total += sub;
                }
                count++;
            }
            dr = dt.NewRow();
            dr["Price per Quantity"] = "Total (RM):";
            dr["Subtotal"] = total;
            Session["total"] = total;
            dt.Rows.Add(dr);

            gvCheckOut.DataSource = dt;
            gvCheckOut.DataBind();
        }

        protected void btnPaypal_Click(object sender, EventArgs e)
        {
            bool ch = checkAddress();
            int count = 0;
            cvAddressLine.ErrorMessage = "";
            cvState.ErrorMessage = "";
            cvCity.ErrorMessage = "";
            cvZipCode.ErrorMessage = "";
            if (ch)
            {
                foreach (var p in lvAddress.Items)
                {
                    CheckBox chk = (CheckBox)p.FindControl("chkAddress");
                    if (chk.Checked)
                    {
                        Session["addId"] = lvAddress.DataKeys[count].Value.ToString();
                    }
                    count++;
                }

                string total = Session["total"].ToString();
                int totalQuantity = 0;
                if (Convert.ToDecimal(total) != 0 || !string.IsNullOrEmpty(total))
                {
                    foreach (string x in cc)
                    {
                        Cart c = db.Carts.SingleOrDefault(
                            a => a.Product_ID == x && a.Buyer_Id == id);
                        if (c != null)
                        {
                            totalQuantity += c.Cart_Quantity;
                        }
                    }
                    //Pay pal process Refer for what are the variable are need to send http://www.paypalobjects.com/IntegrationCenter/ic_std-variable-ref-buy-now.html
                    var redirectUrl = "";
                    //Mention URL to redirect content to paypal site
                    redirectUrl += "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_xclick&business=connetcompany@gmail.com";
                    redirectUrl += "&first_name=" + name;
                    //Product Name
                    redirectUrl += "&item_name= Total";
                    //Product Amount
                    redirectUrl += "&amount=" + total;
                    redirectUrl += "&currency_code=MYR";
                    //Business contact paypal EmailID
                    redirectUrl += "&business=connetcompany@gmail.com";
                    //Shipping charges if any, or available or using shopping cart system
                    redirectUrl += "&shipping=0";
                    //Handling charges if any, or available or using shopping cart system
                    redirectUrl += "&handling=0";
                    //Tax charges if any, or available or using shopping cart system
                    redirectUrl += "&tax=0";
                    //Quantiy of product, Here statically added quantity 1
                    redirectUrl += "&quantity=" + totalQuantity;
                    //If transactioin has been successfully performed, redirect SuccessURL page- this page will be designed by developer
                    redirectUrl += "&return=https://localhost:44377/Viewer/PaymentSuccess.aspx";
                    //If transactioin has been failed, redirect FailedURL page- this page will be designed by developer
                    redirectUrl += "&cancel_return=https://localhost:44377/Viewer/PaymentFailed.aspx";

                    var paypalPath = MapPath("~/Viewer/paypal.png");
                    var imgBarCode = QrCode.QrcodeGenerator(redirectUrl, paypalPath);
                    plqrcode.Controls.Add(imgBarCode);
                    url.NavigateUrl = redirectUrl;
                    url.Text = "Click here if QR code doesnt work";
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Please try again");
                }
            }
            else
            {
                lbError.Text = "Please select a address";
            }

        }


        protected void btnCreditCard_Click(object sender, EventArgs e)
        {
            bool ch = checkAddress();
            int count = 0;
            cvAddressLine.ErrorMessage = "";
            cvState.ErrorMessage = "";
            cvCity.ErrorMessage = "";
            cvZipCode.ErrorMessage = "";
             string userId = "";
            string addId = "";  
            decimal total = 0;
            string checkOut = "";
            userId = Session["id"].ToString();
            addId = Session["addId"].ToString();
            total = Convert.ToDecimal(Session["total"].ToString());
            checkOut = Session["checkout"].ToString();
            if (ch)
            {
                foreach (var p in lvAddress.Items)
                {
                    CheckBox chk = (CheckBox)p.FindControl("chkAddress");
                    if (chk.Checked)
                    {
                        Session["addId"] = lvAddress.DataKeys[count].Value.ToString();
                    }
                    count++;
                }
                //string total = Session["total"].ToString();
                if (Convert.ToDecimal(total) != 0 /*|| !string.IsNullOrEmpty(total.ToString)*/)
                {
                    Response.Redirect("~/Viewer/CreditCard.aspx");
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Logout to register new account");
                }
            }
            else
            {
                
                lbError.Text = "Please select a address";
            
            }
        }

        protected void cvAddressLine_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            string addressLine = Security.ParseOutHTML(args.Value);
            if (string.IsNullOrEmpty(addressLine))
            {
                cvAddressLine.ErrorMessage = "Address Line cannot be empty";
                args.IsValid = false;
            }else if (args.Value.Length > 100)
            {
                cvAddressLine.ErrorMessage = "Address Line is too long";
                args.IsValid = false;
            }
        }

        protected void cvCity_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            string city = Security.ParseOutHTML(args.Value);
            if (string.IsNullOrEmpty(city))
            {
                cvCity.ErrorMessage = "City cannot be empty";
                args.IsValid = false;
            }else if (args.Value.Length > 30)
            {
                cvCity.ErrorMessage = "City cannot exceed 30 characters";
                args.IsValid = false;
            }
        }

        protected void cvState_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            string state = Security.ParseOutHTML(args.Value);
            if (string.IsNullOrEmpty(state))
            {
                cvState.ErrorMessage = "State cannot be empty";
                args.IsValid = false;
            }else if (args.Value.Length>30)
            {
                cvState.ErrorMessage = "State cannot exceed 30 characters";
                args.IsValid = false;
            }
        }

        protected void cvZipCode_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            string zipCode = Security.ParseOutHTML(args.Value);
            if (string.IsNullOrEmpty(zipCode))
            {
                cvZipCode.ErrorMessage = "Zip Code cannot be empty";
                args.IsValid = false;
            }else if (args.Value.Length > 5)
            {
                cvZipCode.ErrorMessage = "Zip Code more than 5";
                args.IsValid = false;
            }
        }
        protected bool checkAddress()
        {
            int i = 0;
            foreach (var p in lvAddress.Items)
            {
                CheckBox chk = (CheckBox)p.FindControl("chkAddress");
                if (chk.Checked)
                {
                    i++;
                }
            }
            if (i > 1 || i < 1)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

        protected void btnAddAddress_Click(object sender, EventArgs e)
        {
            bool repeatId = false;
            string addressId = "";
            string id = Session["id"].ToString();
            if (Page.IsValid)
            {
                string ad = txtAddressLine.Text;
                string ci = txtCity.Text;
                string co = txtZipCode.Text;
                string st = txtState.Text;
                do
                {
                    addressId = Security.autoId('O');
                    var same = db.Orders.SingleOrDefault(
                        s => s.Id == id);
                    if (same == null) repeatId = true;
                } while (repeatId == false);
                Address a = new Address
                {
                    Id = addressId,
                    AddressLine = ad,
                    City = ci,
                    ZipCode = co,
                    State = st,
                    Buyer_ID = id
                };
                db.Addresses.InsertOnSubmit(a);
                db.SubmitChanges();
                Response.Redirect("~/Viewer/CheckOut.aspx");
            }
        }
    }
}