﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApp_Assignment.csFile;

namespace WebApp_Assignment.Viewer
{
    public partial class View : Page
    {
        ConnetDataContext db = new ConnetDataContext();
        public static ProductInfo ProductInfo = new ProductInfo(null, null, 0, 0, null, null);

        protected void Page_Load(object sender, EventArgs e)
        {
            var roomid = Request.QueryString["roomid"];

            if (roomid != null)
            {
                roomID.Value = roomid;
            }
            else
            {
                Response.Redirect("~/Error.aspx?");
            }

            if (!string.IsNullOrEmpty(Session["name"] as string))
            {
                if (Session["role"].ToString() == "Buyer")
                {
                    userField.Value = Session["name"].ToString();
                }
                else if (Session["role"].ToString() == "Seller")
                {
                    Response.Redirect("~/Error.aspx?errmsg=You are not allow to join view page.");
                }
            }
            else
            {
                txtMessage.Enabled = false;
                btnSend.CssClass = "btn btn-outline-primary disabled";
                btnSend.Enabled = false;
            }

            Page.DataBind();
        }

        protected void productInfo_Click(object sender, EventArgs e)
        {
            LinkButton lb = (LinkButton)(sender);
            string productID = lb.CommandArgument;

            Product p = db.Products.SingleOrDefault(x => x.Id == productID);

            if (p != null)
            {
                ProductInfo.id = p.Id;
                ProductInfo.name = p.Name;
                ProductInfo.price = p.Price;
                ProductInfo.quantity = p.Quantity;
                ProductInfo.desc = p.Description;
                ProductInfo.sellerId = p.Seller_ID;
            }
        }

        protected void onItemCommand(object sender, ListViewCommandEventArgs e)
        {
            if (e.CommandName == "product")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                string id = product.DataKeys[index].Value.ToString();

                Product p = db.Products.SingleOrDefault(x => x.Id == id);

                if (p != null)
                {
                    ProductInfo.id = p.Id;
                    ProductInfo.name = p.Name;
                    ProductInfo.price = p.Price;
                    ProductInfo.quantity = p.Quantity;
                    ProductInfo.desc = p.Description;
                    ProductInfo.sellerId = p.Seller_ID;
                }
            }
        }

        protected void item_Click(object sender, EventArgs e)
        {
            string productID = productValue.Value;

            Product p = db.Products.SingleOrDefault(x => x.Id == productID);

            if (p != null)
            {
                ProductInfo.id = p.Id;
                ProductInfo.name = p.Name;
                ProductInfo.price = p.Price;
                ProductInfo.quantity = p.Quantity;
                ProductInfo.desc = p.Description;
                ProductInfo.sellerId = p.Seller_ID;
            }
        }
    }
}