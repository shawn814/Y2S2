﻿(function () {
    var room_id = $("#content_roomID").val();

    $(function () {
        window.enableAdapter = true;

        var connection = new RTCMultiConnection();

        connection.codecs.video = "H264";

        connection.mediaConstraints = {
            video: {
                mandatory: {
                    minWidth: 1280,
                    maxWidth: 1280,
                    minHeight: 720,
                    maxHeight: 720,
                    minFrameRate: 30,
                    minAspectRatio: 1.77
                },
                optional: [
                    {
                        facingMode: "user" // or "application"
                    }
                ]
            },
            audio: {
                mandatory: {
                    echoCancellation: false, // disabling audio processing
                    googAutoGainControl: true,
                    googNoiseSuppression: true,
                    googHighpassFilter: true,
                    googTypingNoiseDetection: true,
                    //googAudioMirroring: true
                },
                optional: []
            }
        };

        connection.session = {
            audio: false,
            video: false,
            oneway: true // only first person shares the video
        };

        connection.sdpConstraints.mandatory = {
            OfferToReceiveAudio: false,
            OfferToReceiveVideo: false
        };

        connection.socketURL = "https://rtcmulticonnection.herokuapp.com:443/";
        //connection.setCustomSocketHandler(SignalRConnection);

        connection.checkPresence(room_id, function (isRoomExist, roomid) {
            if (isRoomExist === true) {
                connection.join(roomid);
            } else {
                console.log("No room found");
                $(location).attr('href', '/Error.aspx');
                $(window).attr('location', '/Error.aspx');
                $(location).prop('href', '/Error.aspx');
            }
        });

        connection.onstream = function (event) {
            if (event.type === "remote") {
                try {
                    document.getElementById("view").srcObject = event.stream;
                } catch (e) {
                    document.getElementById("view").src = URL.createObjectURL(event.stream);
                }
                //setInterval(function () { $("#views").text(connection.getAllParticipants().length); }, 1000);
            }
        };

        //window.streamid = event.stream;
        //connection.streamEvents[event.streamid].stream.mute('audio');
    });

    var viewChat = $.connection.publicHub;
    // Declare function on the chat hub
    viewChat.client.sendMessage = function (roomID, name, message) {
        // Html encode display name and message
        if (roomID === room_id) {
            var username = $("<div />").text(name).html();
            var chatMessage = $("<div />").text(message).html();
            if (name === $("#content_userField").val())
                $("#chatContent").append("<p>" + username + "</p>" + "<li class='sender'>" + chatMessage + "</li>");
            else
                $("#chatContent").append("<p>" + username + "</p>" + "<li class='receiver'>" + chatMessage + "</li>");
        }
    };

    viewChat.client.viewReceive = function (roomID, views) {
        if (roomID === room_id) {
            $("#views").text(views);
        }
    };

    // Start connection
    $.connection.hub.start().done(function () {
        $("#content_btnSend").click(function (e) {
            e.preventDefault();
            if ($("#content_txtMessage").val() && $("#content_userField").val()) {
                viewChat.server.sendToAll(room_id, $("#content_userField").val(), $("#content_txtMessage").val());
                $("#content_txtMessage").val("").focus();
            }
        });
    });
})();