﻿(function () {
    var connection = new RTCMultiConnection();
    var roomid;

    $(function () {
        roomid = $("#content_roomid").val();
        window.enableAdapter = true;

        connection.codecs.video = "H264";

        connection.socketURL = "https://rtcmulticonnection.herokuapp.com:443/";
        //connection.setCustomSocketHandler(SignalRConnection);

        connection.mediaConstraints = {
            video: {
                mandatory: {
                    minWidth: 1280,
                    maxWidth: 1280,
                    minHeight: 720,
                    maxHeight: 720,
                    minFrameRate: 30,
                    minAspectRatio: 1.77
                },
                optional: [
                    {
                        facingMode: "user" // or "application"
                    }
                ]
            },
            audio: {
                mandatory: {
                    echoCancellation: false, // disabling audio processing
                    googAutoGainControl: true,
                    googNoiseSuppression: true,
                    googHighpassFilter: true,
                    googTypingNoiseDetection: true,
                    //googAudioMirroring: true
                },
                optional: []
            }
        };

        connection.session.oneway = true;

        connection.sdpConstraints.mandatory = {
            OfferToReceiveAudio: false,
            OfferToReceiveVideo: false
        };

        connection.open(roomid);

        connection.onstream = function (event) {
            if (event.type === "local") {
                try {
                    document.getElementById("broadcast").srcObject = event.stream;
                } catch (e) {
                    document.getElementById("broadcast").src = URL.createObjectURL(event.stream);
                }
            }
        };
        console.log("Room ID = " + roomid);
    });

    $(function () {
        $("#add_btn").click(function (e) {
            e.preventDefault();
        });

        $("#content_ListView2_Product_check_0").click(function (e) {
            $("#list-all-item").toggleClass("item-wrap-onclick");
        });
    });

    var viewChat = $.connection.publicHub;
    // Declare function on the chat hub
    viewChat.client.sendMessage = function (roomID, name, message) {
        // Html encode display name and message
        if (roomid === roomID) {
            var username = $("<div />").text(name).html();
            var chatMessage = $("<div />").text(message).html();
            $("#chatContent").append("<li>" + username + ":&nbsp;&nbsp;" + chatMessage + "</li>");
        }
    };

    // Start connection
    $.connection.hub.start().done(function () {
        console.log("Signalr Connected");

        $("#btnSend").click(function (e) {
            e.preventDefault();
            if ($("#txtMessage").val() && $("#content_sellerField").val()) {
                viewChat.server.sendToAll(roomid, $("#content_sellerField").val(), $("#txtMessage").val());
                $("#txtMessage").val("").focus();
            }
        });

        setInterval(function () {
            $("#views").text(connection.getAllParticipants().length);
            viewChat.server.viewSend(roomid, connection.getAllParticipants().length);
        }, 1000);

        $(window).bind("beforeunload", function () {
            viewChat.server.broadcastEnd();
        });

        $(window).bind("unload", function () {
            viewChat.server.broadcastEnd();
        });
    });
})();