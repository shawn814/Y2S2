﻿var fid;
var femail;
var fname;
window.fbAsyncInit = function () {
    FB.init({
        appId: '2161497184068259',
        cookie: false,
        xfbml: true,
        version: 'v3.2'
    });

    FB.getLoginStatus(function (response) {
        statusChangeCallback(response);
    });
};

(function (d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.2';
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function statusChangeCallback(response) {
    if (response.status === 'connected') {
        console.log('Logged in and authenticated');
        setElements(true);
        testAPI();
    }
    else {
        console.log('Not authenticated');
        setElements(false);
    }
}

function checkLoginState() {
    FB.getLoginStatus(function (response) {
        statusChangeCallback(response);
    });
}

function setElements(isLoggedIn) {
    if (isLoggedIn) {
        document.getElementById('fb-btn').style.display = 'none';
        document.getElementById('logout').style.display = 'block';
    } else {
        document.getElementById('fb-btn').style.display = 'block';
        document.getElementById('logout').style.display = 'none';
    }
}

function logout() {
    FB.logout(function () {
        window.location.reload();
        //setElements(false);
    });
}

function testAPI() {
    FB.api("/me?fields=id,name,email", function (response) {
        console.log(response.id, response.email);
        if (response && !response.error) {

            fid = response.id;
            fname = response.name;
            femail = response.email;
            window.location = "/Authentication/facebookLogin.aspx?fid=" + fid + "&em=" + femail + "&na=" + fname;
        }
    });
}