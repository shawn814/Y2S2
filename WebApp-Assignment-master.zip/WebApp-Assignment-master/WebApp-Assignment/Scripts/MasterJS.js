﻿$(function() {
    $('input[type="file"]').change(function (e) {
        try {
            var fileName = e.target.files[0].name;
            $('.custom-file-label').html(fileName);
        } catch (e) {
            $('.custom-file-label').html("Choose file");
        }
    });


})