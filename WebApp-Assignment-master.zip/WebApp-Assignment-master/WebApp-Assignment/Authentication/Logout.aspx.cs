﻿using System;
using System.Web;
using System.Web.Security;
using System.Web.UI;

namespace WebApp_Assignment.Authentication
{
    public partial class Logout : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.RemoveAll();
        }
    }
}