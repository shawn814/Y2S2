﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Authentication
{
    public partial class Login : Page
    {
        private ConnetDataContext database = new ConnetDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Session["name"] as string)) Response.Redirect("~/Home.aspx");
        }

        protected void emailValid_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (string.IsNullOrEmpty(args.Value))
            {
                emailValid.ErrorMessage = "Email is empty";
                args.IsValid = false;
            }
        }

        protected void passwordValid_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (string.IsNullOrEmpty(args.Value))
            {
                passwordValid.ErrorMessage = "Password is empty";
                args.IsValid = false;
            }
        }

        protected void Login_Click(object sender, EventArgs e)
        {
            var stringEmail = txtemail.Text;
            var stringPassword = txtpassword.Text;
            var u = database.users.SingleOrDefault(
                a => a.Email == stringEmail &&
                     a.password == Security.GetHash(stringPassword));
            var testUser = database.users.SingleOrDefault(
                a => a.Email == stringEmail);
            if (testUser != null)
            {
                if (u == null)
                {
                    userValidate.ErrorMessage = "The password is incorrect";
                    addError(testUser.Id, testUser.role);
                    userValidate.IsValid = false;
                }
                else if (u.emailConfirm == false)
                {
                    userValidate.ErrorMessage = "The email is not verified yet <br/> The verified email is sent";
                    csFile.Email.Send(u.Username,u.Email,u.Id,null,"cEmail");
                    userValidate.IsValid = false;
                }
                else if (u.accessFailedCount > 3)
                {
                    userValidate.ErrorMessage = "This account has been login too many times";
                    userValidate.IsValid = false;
                }
                else
                {
                    Session["id"] = u.Id;
                    Session["role"] = u.role;
                    Session["name"] = u.Username;
                    clearError(u.Id, u.role);
                    Response.Redirect("~/Home.aspx");
                }
            }
            else
            {
                userValidate.ErrorMessage = "The email haven't be registered yet!!";
                userValidate.IsValid = false;
            }
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }

        public void addError(string id, string role)
        {
            if (role == "Buyer")
            {
                Buyer b = database.Buyers.SingleOrDefault(
                    a => a.Id == id);
                b.accessFailedCount++;
                database.SubmitChanges();
            }
            else if(role == "Seller")
            {
                Seller s = database.Sellers.SingleOrDefault(
                    a => a.Id == id);
                s.accessFailedCount++;
                database.SubmitChanges();
            }
        }
        public void clearError(string id, string role)
        {
            if (role == "Buyer")
            {
                Buyer b = database.Buyers.SingleOrDefault(
                    a => a.Id == id);
                b.accessFailedCount = 0;
                database.SubmitChanges();
            }
            else if (role == "Seller")
            {
                Seller s = database.Sellers.SingleOrDefault(
                    a => a.Id == id);
                s.accessFailedCount = 0;
                database.SubmitChanges();
            }
        }
    }
  
}