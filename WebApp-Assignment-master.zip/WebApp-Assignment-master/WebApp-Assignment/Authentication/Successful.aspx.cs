﻿using System;
using System.Web.UI;

namespace WebApp_Assignment.Login
{
    public partial class Successful : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}