﻿using Connet;
using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Authentication
{
    public partial class Register : Page
    {
        private ConnetDataContext db = new ConnetDataContext();
        public static string getType;

        protected void Page_Load(object sender, EventArgs e)
        {
            getType = Request.QueryString["type"];

            if (!string.IsNullOrEmpty(Session["role"] as string))
            {
                if (Session["role"].ToString().ToUpper() == "BUYER" || Session["role"].ToString().ToUpper() == "SELLER")
                {
                    Response.Redirect("~/Error.aspx?errmsg=Logout to register new account");
                }
                else if (Session["role"].ToString().ToUpper() == "STAFF")
                {
                    Response.Redirect("~/Error.aspx?errmsg=You dont have permission to register");
                }
                else if (!(Session["role"].ToString().ToUpper() == "ADMIN" && (getType.ToUpper() == "STAFF" || getType.ToUpper() == "ADMIN")))
                {
                    Response.Redirect("~/Error.aspx?errmsg=You dont have permission to register");
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(getType))
                {
                    if (getType.ToLower() != "buyer" && getType.ToLower() != "seller")
                    {
                        Response.Redirect("~/Error.aspx");
                    }
                }
            }
        }

        //---------------Buyer123asdASD
        protected void fullnameValidB_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var st = Validation.usernameValidate(args.Value);
            if (!string.IsNullOrEmpty(st))
            {
                fullNameValidB.ErrorMessage = st;
                args.IsValid = false;
            }
        }

        protected void emailValidB_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errEmail = Validation.emailValidate(args.Value);
            bool sameEmail = emailDetect(args.Value);
            if (!string.IsNullOrEmpty(errEmail))
            {
                emailValidB.ErrorMessage = errEmail;
                args.IsValid = false;
            }else if (sameEmail)
            {
                emailValidB.ErrorMessage = "The email has been used";
                args.IsValid = false;
            }
        }

        protected void passwordValidB_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPassword = Validation.passwordValidate(args.Value);
            if (!string.IsNullOrEmpty(errPassword))
            {
                passwordValidB.ErrorMessage = errPassword;
                args.IsValid = false;
            }
        }

        protected void confirmPasswordValidB_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var password = Convert.ToString(txtPasswordB.Text);
            if (string.IsNullOrEmpty(args.Value))
            {
                confirmPasswordValidB.ErrorMessage = "The confirm password cannot be empty";
                args.IsValid = false;
            }
            else if (args.Value != password)
            {
                confirmPasswordValidB.ErrorMessage = "The confirm password didnt match with the password";
                args.IsValid = false;
            }
        }

        //------------Seller
        protected void fullnameValidS_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var st = Validation.usernameValidate(args.Value);
            if (!string.IsNullOrEmpty(st))
            {
                fullNameValidS.ErrorMessage = st;
                args.IsValid = false;
            }
        }

        protected void emailValidS_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errEmail = Validation.emailValidate(args.Value);
            bool sameEmail = emailDetect(args.Value);
            if (!string.IsNullOrEmpty(errEmail))
            {
                emailValidS.ErrorMessage = errEmail;
                args.IsValid = false;
            }
            else if (sameEmail)
            {
                emailValidB.ErrorMessage = "The email has been used";
                args.IsValid = false;
            }
        }

        protected void passwordValidS_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPassword = Validation.passwordValidate(args.Value);
            if (!string.IsNullOrEmpty(errPassword))
            {
                passwordValidS.ErrorMessage = errPassword;
                args.IsValid = false;
            }
        }

        protected void confirmPasswordValidS_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var password = Convert.ToString(txtPasswordS.Text);
            if (string.IsNullOrEmpty(args.Value))
            {
                confirmPasswordValidS.ErrorMessage = "The confirm password cannot be empty";
                args.IsValid = false;
            }
            else if (args.Value != password)
            {
                confirmPasswordValidS.ErrorMessage = "The confirm password didnt match with the password";
                args.IsValid = false;
            }
        }

        //-----------Staff
        protected void fullnameValidT_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var st = Validation.usernameValidate(args.Value);
            if (!string.IsNullOrEmpty(st))
            {
                fullNameValidT.ErrorMessage = st;
                args.IsValid = false;
            }
        }

        protected void emailValidT_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errEmail = Validation.emailValidate(args.Value);
            bool sameEmail = emailDetect(args.Value);
            if (!string.IsNullOrEmpty(errEmail))
            {
                emailValidT.ErrorMessage = errEmail;
                args.IsValid = false;
            }
            else if (sameEmail)
            {
                emailValidB.ErrorMessage = "The email has been used";
                args.IsValid = false;
            }
        }

        protected void passwordValidT_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPassword = Validation.passwordValidate(args.Value);
            if (!string.IsNullOrEmpty(errPassword))
            {
                passwordValidT.ErrorMessage = errPassword;
                args.IsValid = false;
            }
        }

        protected void confirmPasswordValidT_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var password = Convert.ToString(txtPasswordT.Text);
            if (string.IsNullOrEmpty(args.Value))
            {
                confirmPasswordValidT.ErrorMessage = "The confirm password cannot be empty";
                args.IsValid = false;
            }
            else if (args.Value != password)
            {
                confirmPasswordValidT.ErrorMessage = "The confirm password didnt match with the password";
                args.IsValid = false;
            }
        }
        //----------Admin

        protected void fullnameValidA_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var st = Validation.usernameValidate(args.Value);
            if (!string.IsNullOrEmpty(st))
            {
                fullNameValidA.ErrorMessage = st;
                args.IsValid = false;
            }
        }

        protected void emailValidA_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errEmail = Validation.emailValidate(args.Value);
            bool sameEmail = emailDetect(args.Value);
            if (!string.IsNullOrEmpty(errEmail))
            {
                emailValidA.ErrorMessage = errEmail;
                args.IsValid = false;
            }
            else if (sameEmail)
            {
                emailValidB.ErrorMessage = "The email has been used";
                args.IsValid = false;
            }
        }

        protected void passwordValidA_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPassword = Validation.passwordValidate(args.Value);
            if (!string.IsNullOrEmpty(errPassword))
            {
                passwordValidA.ErrorMessage = errPassword;
                args.IsValid = false;
            }
        }

        protected void confirmPasswordValidA_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var password = Convert.ToString(txtPasswordA.Text);
            if (string.IsNullOrEmpty(args.Value))
            {
                confirmPasswordValidA.ErrorMessage = "The confirm password cannot be empty";
                args.IsValid = false;
            }
            else if (args.Value != password)
            {
                confirmPasswordValidA.ErrorMessage = "The confirm password didnt match with the password";
                args.IsValid = false;
            }
        }

        protected void SubmitB_Click(object sender, EventArgs e)
        {
            validA();
            validS();
            validT();
            var username = txtFullNameB.Text;
            var password = txtPasswordB.Text;
            var email = txtEmailB.Text;
            var EncodedResponse = Request.Form["g-Recaptcha-Response"];
            var IsCaptchaValid = ReCaptchaClass.Validate(EncodedResponse) == "true" ? true : false;

            string id;
            var repeatId = false;
            var u = db.users.SingleOrDefault(
                a => a.Email == email);
            do
            {
                id = Security.autoId('B');
                var same = db.users.SingleOrDefault(
                    s => s.Id == id);
                if (same == null) repeatId = true;
            } while (repeatId == false);
            if (IsCaptchaValid)
            {
                if (Page.IsValid)
                {
                    if (u == null)
                    {
                        var b = new Buyer
                        {
                            Id = id,
                            username = username,
                            email = email,
                            password = Security.GetHash(password),
                            emailConfirm = false,
                            accessFailedCount = 0
                        };
                        db.Buyers.InsertOnSubmit(b);
                        db.SubmitChanges();
                        Response.Redirect("~/Authentication/Login.aspx");
                    }
                    else
                    {
                        userValidateB.ErrorMessage = "The account is used";
                        userValidateB.IsValid = false;
                    }
                }
            }
            else
            {
                userValidateB.ErrorMessage= "Please verified the recaptcha";
                userValidateB.IsValid = false;
            }
        }

        protected void SubmitS_Click(object sender, EventArgs e)
        {
            validB();
            validT();
            validA();

            var username = txtFullNameS.Text;
            var password = txtPasswordS.Text;
            var email = txtEmailS.Text;
            var EncodedResponse = Request.Form["g-Recaptcha-Response"];
            var IsCaptchaValid = ReCaptchaClass.Validate(EncodedResponse) == "true" ? true : false;

            string id;
            var repeatId = false;
            var u = db.users.SingleOrDefault(
                a => a.Email == email);
            do
            {
                id = Security.autoId('S');
                var same = db.users.SingleOrDefault(
                    s => s.Id == id);
                if (same == null) repeatId = true;
            } while (repeatId == false);
            if (IsCaptchaValid)
            {
                if (Page.IsValid)
                {
                    if (u == null)
                    {
                        var s = new Seller
                        {
                            Id = id,
                            username = username,
                            email = email,
                            password = Security.GetHash(password),
                            emailConfirm = false,
                            accessFailedCount = 0
                        };
                        db.Sellers.InsertOnSubmit(s);
                        db.SubmitChanges();
                        //
                        Response.Redirect("~/Authentication/NewLogin.aspx");
                    }
                    else
                    {
                        userValidateS.ErrorMessage = "The account is used";
                        userValidateS.IsValid = false;
                    }
                }
            }
            else
            {
                userValidateS.ErrorMessage = "Please verified the recaptcha";
                userValidateS.IsValid = false;
            }
        }

        protected void SubmitT_Click(object sender, EventArgs e)
        {
            validA();
            validS();
            validB();

            var username = txtFullNameT.Text;
            var password = txtPasswordT.Text;
            var email = txtEmailT.Text;
            string id;
            var repeatId = false;
            var u = db.users.SingleOrDefault(
                a => a.Email == email);
            do
            {
                id = Security.autoId('T');
                var same = db.users.SingleOrDefault(
                    s => s.Id == id);
                if (same == null) repeatId = true;
            } while (repeatId == false);

            if (Page.IsValid)
            {
                if (u == null)
                {
                    var t = new Staff
                    {
                        Id = id,
                        username = username,
                        email = email,
                        password = Security.GetHash(password)
                    };
                    db.Staffs.InsertOnSubmit(t);
                    db.SubmitChanges();

                    Response.Redirect("~/Authentication/NewLogin.aspx");
                }
                else
                {
                    ErrorT.Text = "The account is used";
                    Response.Redirect("~/Authentication/Register.aspx");
                }
            }
        }

        protected void SubmitA_Click(object sender, EventArgs e)
        {
            validS();
            validT();
            validB();

            var username = txtFullNameA.Text;
            var password = txtPasswordA.Text;
            var email = txtEmailA.Text;
            string id;
            var repeatId = false;
            var u = db.users.SingleOrDefault(
                a => a.Email == email);
            do
            {
                id = Security.autoId('A');
                var same = db.users.SingleOrDefault(
                    s => s.Id == id);
                if (same == null) repeatId = true;
            } while (repeatId == false);

            if (Page.IsValid)
            {
                if (u == null)
                {
                    var a = new Admin
                    {
                        Id = id,
                        username = username,
                        email = email,
                        password = Security.GetHash(password)
                    };
                    db.Admins.InsertOnSubmit(a);
                    db.SubmitChanges();

                    Response.Redirect("~/Authentication/NewLogin.aspx");
                }
                else
                {
                    ErrorA.Text = "The account is used";
                    Response.Redirect("~/Authentication/Register.aspx");
                }
            }
        }

        public void validA()
        {
            fullNameValidA.IsValid = true;
            passwordValidA.IsValid = true;
            emailValidA.IsValid = true;
            confirmPasswordValidA.IsValid = true;
        }

        public void validB()
        {
            fullNameValidB.IsValid = true;
            passwordValidB.IsValid = true;
            confirmPasswordValidB.IsValid = true;
            emailValidB.IsValid = true;
        }

        public void validS()
        {
            fullNameValidS.IsValid = true;
            passwordValidS.IsValid = true;
            confirmPasswordValidS.IsValid = true;
            emailValidS.IsValid = true;
        }

        public void validT()
        {
            fullNameValidT.IsValid = true;
            passwordValidT.IsValid = true;
            confirmPasswordValidT.IsValid = true;
            emailValidT.IsValid = true;
        }
        public bool emailDetect(string email)
        {
            user l = db.users.SingleOrDefault(
                a => a.Email == email);
            if (l != null) //got duplicate
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}