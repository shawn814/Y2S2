﻿using System;
using System.Linq;
using System.Web.UI;

namespace WebApp_Assignment.Authentication
{
    public partial class EditProfile : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                var userFound = false;
                if (!string.IsNullOrEmpty(Session["role"] as string))
                {
                    if (Session["role"].ToString() == "Buyer")
                    {
                        var u = db.Buyers.SingleOrDefault(x => x.Id == Session["id"].ToString());

                        if (u != null)
                        {
                            userId.Text = u.Id;
                            userEmail.Text = u.email;
                            userName.Text = u.username;
                            userPhone.Text = u.phoneNumber;
                            userGender.SelectedValue = Convert.ToString(u.gender);
                            userFound = true;
                        }
                    }
                    else if (Session["role"].ToString() == "Seller")
                    {
                        var u = db.Sellers.SingleOrDefault(x => x.Id == Session["id"].ToString());

                        if (u != null)
                        {
                            userId.Text = u.Id;
                            userEmail.Text = u.email;
                            userName.Text = u.username;
                            userPhone.Text = u.phoneNumber;
                            userGender.SelectedValue = Convert.ToString(u.gender);
                            userFound = true;
                        }
                    }
                    else
                    {
                        Response.Redirect("~/Error.aspx?errmsg=You are not able to edit profile");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=You are not login any account");
                }

                if (!userFound) Response.Redirect("~/Error.aspx?errmsg=Unable to find account");
            }
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            if (Session["role"].ToString() == "Buyer")
            {
                var u = db.Buyers.SingleOrDefault(x => x.Id == Session["id"].ToString());

                if (u != null)
                {
                    u.username = userName.Text.Trim();
                    u.phoneNumber = userPhone.Text.Trim();
                    u.gender = Convert.ToChar(userGender.SelectedValue);
                    db.SubmitChanges();
                    Response.Redirect("~/Authentication/Profile.aspx");
                }
            }
            else if (Session["role"].ToString() == "Seller")
            {
                var u = db.Sellers.SingleOrDefault(x => x.Id == Session["id"].ToString());

                if (u != null)
                {
                    u.username = userName.Text.Trim();
                    u.phoneNumber = userPhone.Text.Trim();
                    u.gender = Convert.ToChar(userGender.SelectedValue);
                    db.SubmitChanges();
                    Response.Redirect("~/Authentication/Profile.aspx");
                }
            }
            else
            {
                Response.Redirect("~/Error.aspx?errmsg=You are not able to edit profile");
            }
        }
    }
}