﻿using System;
using System.Linq;
using System.Web.UI;

namespace WebApp_Assignment.Authentication
{
    public partial class facebookLogin : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            var name = Request.QueryString["na"];
            var email = Request.QueryString["em"];
            var id = "F" + Request.QueryString["fid"];

           
            var s = db.users.SingleOrDefault(x => x.Email == email);
            if (s != null)
            {
                clearError(s.Id, s.role);
                Session["id"] = s.Id;
                Session["name"] = s.Username;
                Session["role"] = s.role;
            }
            else
            {
                var b = new Buyer
                {
                    Id = id,
                    email = email,
                    username = name,
                    emailConfirm = true,
                    phoneNumber = "123",
                    accessFailedCount = 0,
                    password = Guid.NewGuid().ToString("N")
                };
                db.Buyers.InsertOnSubmit(b);
                db.SubmitChanges();
                Session["id"] = id;
                Session["name"] = name;
                Session["role"] = "Buyer";
            }
            Response.Redirect("~/Home.aspx");
        }
        public void clearError(string id, string role)
        {
            if (role == "Buyer")
            {
                Buyer b = db.Buyers.SingleOrDefault(
                    a => a.Id == id);
                b.accessFailedCount = 0;
                db.SubmitChanges();
            }
            else if (role == "Seller")
            {
                Seller s = db.Sellers.SingleOrDefault(
                    a => a.Id == id);
                s.accessFailedCount = 0;
                db.SubmitChanges();
            }
        }
    }
}