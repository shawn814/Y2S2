﻿using System;
using System.Web.UI;
using System.Linq;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Authentication
{
    public partial class Email : Page
    {
        private ConnetDataContext database = new ConnetDataContext();
        string pinInSession = "";
        public string email,id,pin;
        protected void Page_Load(object sender, EventArgs e)
        {
            email = Request.QueryString["em"];
            id = Request.QueryString["userId"];
            pin = Request.QueryString["pin"];
            if (!string.IsNullOrEmpty(Session["pin"] as string))
            {
                pinInSession = Session["pin"].ToString();
            }
            else
            {
                Response.Redirect("~/Home.aspx");
            }
            if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(id))
            {
                user u = database.users.SingleOrDefault(
                    a => a.Email == email && a.Id == id);
                if (u != null)
                {
                    ConfirmEmail(id, u.role);
                    Response.Redirect("~/Authentication/Login.aspx");
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Please try again");
                }
            }
            else if (!string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(pin))
            {
                if (!string.IsNullOrEmpty(pin) || !!string.IsNullOrEmpty(Session["temp_token"] as string))
                {
                    if (Session["temp_token"].ToString() != pin)
                    {
                        Response.Redirect("~/Error.aspx?errmsg=Please try again");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=Please use the same device to update password");
                }
            }
        }
        public void ConfirmEmail(string id, string role)
        {
            if (role == "Buyer")
            {
                Buyer b = database.Buyers.SingleOrDefault(
                    a => a.Id == id);
                b.emailConfirm = true;
                database.SubmitChanges();
            }
            else if(role == "Seller")
            {
                Seller s = database.Sellers.SingleOrDefault(
                    a => a.Id == id);
                s.emailConfirm = true;
                database.SubmitChanges();
            }
        }
        public void changePassword(string id, string role, string pass)
        {
            if (role == "Buyer")
            {
                Buyer b = database.Buyers.SingleOrDefault(
                    a => a.Id == id);
                b.password = Security.GetHash(pass);
                database.SubmitChanges();
            }
            else if (role == "Seller")
            {
                Seller s = database.Sellers.SingleOrDefault(
                    a => a.Id == id);
                s.password = Security.GetHash(pass);
                database.SubmitChanges();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            user u = database.users.SingleOrDefault(
                   a=> a.Email == email);
            if (Page.IsValid)
            {
                btnSubmit.Enabled = false;
                string pass = txtPassword.Text;
                if (u != null)
                {
                    changePassword(u.Id, u.role, pass);
                    Response.Redirect("~/Authentication/Login.aspx");
                }
            }
        }
        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Authentication/Login.aspx");
        }

        protected void cvPassword_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPassword = Validation.passwordValidate(args.Value);
            if (!string.IsNullOrEmpty(errPassword))
            {
                cvPassword.ErrorMessage = errPassword;
                args.IsValid = false;
            }
        }

        protected void cvRePassword_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs args)
        {
            var password = Convert.ToString(txtPassword.Text);
            if (string.IsNullOrEmpty(args.Value))
            {
                cvRePassword.ErrorMessage = "The confirm password cannot be empty";
                args.IsValid = false;
            }
            else if (args.Value != password)
            {
                cvRePassword.ErrorMessage = "The confirm password didnt match with the password";
                args.IsValid = false;
            }
        }
    }
}