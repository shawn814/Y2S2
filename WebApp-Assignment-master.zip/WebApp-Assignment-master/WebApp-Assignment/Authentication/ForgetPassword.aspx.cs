﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Authentication
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        ConnetDataContext db = new ConnetDataContext();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(Session["id"] as string))
            {
                Response.Redirect("~/Home.aspx");
            }
            if (string.IsNullOrEmpty(Session["temp_token"] as string))
            {
                Response.Redirect("~/Error.aspx?errmsg=Redebug the program");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            btnSubmit.Enabled = false;

            string pin = Session["temp_token"].ToString();
            string email = txtEmail.Text;
            user u = db.users.SingleOrDefault(
                a => a.Email == email);
            csFile.Email.Send(u.Username, u.Email, u.Id, pin, "rPassword");
            Session["pin"] = pin;
            Response.Redirect("~/Authentication/Login.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }
    }
}