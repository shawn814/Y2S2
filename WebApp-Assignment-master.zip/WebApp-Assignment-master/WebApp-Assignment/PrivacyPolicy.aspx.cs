﻿using System;
using System.Web.UI;

namespace WebApp_Assignment
{
    public partial class PrivacyPolicy : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}