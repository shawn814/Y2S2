﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment.Report
{
    public partial class SummaryReport : System.Web.UI.Page
    {
        ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void linqSummary_Selecting(object sender, LinqDataSourceSelectEventArgs e)
        {
            var list = (from t in db.Summaries
                        orderby t.Quantity descending
                        select t).Take(5)
                ;
            e.Result = list;
        }
    }
}