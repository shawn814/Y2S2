﻿using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using Helpers;

namespace WebApp_Assignment.Broadcaster
{
    public partial class AddProduct : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Session["role"] as string) || Session["role"].ToString() != "Seller")
            {
                Response.Redirect("~/Error.aspx?errmsg=You are not allow to add product.");
            }
        }

        protected void addP_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                var name = txtName.Text;
                var quantity = Convert.ToInt32(txtQuantity.Text);
                var desc = txtDescription.Text;
                var price = Convert.ToDecimal(txtPrice.Text);
                var ids = Session["id"].ToString();
                string productId;
                var repeatId = false;

                do
                {
                    productId = Security.autoId('P');
                    var pro = db.Products.SingleOrDefault(
                        s => s.Id == productId);
                    if (pro == null) repeatId = true;
                } while (repeatId == false);

                var path = MapPath("~/Product_image/");

                var img = new SimpleImage(fuImage.FileContent);
                img.Square();
                img.Resize(150);
                img.SaveAs(path + productId + ".jpg");

                var p = new Product
                {
                    Id = productId,
                    Name = name,
                    Quantity = quantity,
                    Description = desc,
                    Price = price,
                    Seller_ID = ids,
                    Active = true
                };
                db.Products.InsertOnSubmit(p);
                db.SubmitChanges();
                Response.Redirect("~/Broadcaster/AddProduct.aspx");
            }
        }

        protected void cvName_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errName = productValidation.pName(args.Value);
            if (!string.IsNullOrEmpty(errName))
            {
                cvName.ErrorMessage = errName;
                args.IsValid = false;
            }
        }

        protected void cvQuantity_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errQuantity = productValidation.pQuantity(args.Value);
            if (!string.IsNullOrEmpty(errQuantity))
            {
                cvQuantity.ErrorMessage = errQuantity;
                args.IsValid = false;
            }
        }

        protected void cvDescription_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errDesc = productValidation.pDesc(args.Value);
            if (!string.IsNullOrEmpty(errDesc))
            {
                cvDescription.ErrorMessage = errDesc;
                args.IsValid = false;
            }
        }

        protected void cvPrice_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPrice = productValidation.pPrice(args.Value);
            if (!string.IsNullOrEmpty(errPrice))
            {
                cvPrice.ErrorMessage = errPrice;
                args.IsValid = false;
            }
        }
        protected void imgValidation_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var pattern = new Regex(@".+\.(jpg|png|jpeg)$", RegexOptions.IgnoreCase);

            if (string.IsNullOrEmpty(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "No picture chosen";
            }
            else if (!pattern.IsMatch(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "Only JPG and PNG are allowed for [Photo]";
            }
        }
    }
}