﻿using System;
using System.Linq;
using System.Web.UI;

namespace WebApp_Assignment
{
    public partial class Channel : Page
    {
        public static string sId;
        private readonly ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            sId = Request.QueryString["sId"];
            if(string.IsNullOrEmpty(Session["role"] as string) || string.IsNullOrEmpty(Session["id"] as string))
            {
                Response.Redirect("~/Error.aspx?errmsg=Please login!!");
            }
            else
            {
                if (!string.IsNullOrEmpty(sId))
                {
                    var s = db.Sellers.SingleOrDefault(
                        a => a.Id == sId);

                    if (s != null)
                    {
                        ProfileID.Text = s.Id;
                        ProfileName.Text = s.username;
                        ProfileEmail.Text = s.email;
                        ProfilePhone.Text = s.phoneNumber;
                    }
                    else
                    {
                        Response.Redirect("~/Error.aspx?errmsg=No Seller Found...");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=No Seller Found");
                }
            }
            
        }
    }
}