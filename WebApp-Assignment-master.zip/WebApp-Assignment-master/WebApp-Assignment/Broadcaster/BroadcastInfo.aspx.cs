﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WebApp_Assignment.csFile;
using Helpers;

namespace WebApp_Assignment.Broadcaster
{
    public partial class BroadcastInfo : Page
    {
        public static List<ProductInfo> SellingProductList;
        public static List<ProductInfo> AllProducts = new List<ProductInfo>();

        private readonly ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Session["sellProductList"] as string))
                SellingProductList = (List<ProductInfo>)Session["sellProductList"];

            if (!string.IsNullOrEmpty(Session["role"] as string) && Session["role"].ToString() == "Seller")
            {
                var products = db.Products.Where(x => x.Seller_ID == Session["id"].ToString());

                if (!string.IsNullOrEmpty(Session["title"] as string))
                {
                    title.Text = Session["title"].ToString();
                    Session.Remove("title");
                }

                foreach (var pd in products)
                    AllProducts.Add(new ProductInfo(pd.Id, pd.Name, pd.Price, pd.Quantity, pd.Description, pd.Seller_ID));

            }
            else
            {
                Response.Redirect(string.IsNullOrEmpty(Session["role"] as string)
                    ? "~/Error.aspx?errmsg=Login seller account to Broadcast"
                    : "~/Error.aspx?errmsg=You dont have permission to Broadcast");
            }
        }

        protected void done_Click(object sender, EventArgs e)
        {
            var index = 0;
            SellingProductList = new List<ProductInfo>();
            foreach (var li in lvProduct.Items)
            {
                var chk = (HtmlInputCheckBox)li.FindControl("chkProduct");
                if (chk.Checked)
                {
                    var product_Id = lvProduct.DataKeys[index].Value.ToString();
                    var p = db.Products.SingleOrDefault(x => x.Id == product_Id);
                    if (p != null)
                        SellingProductList.Add(new ProductInfo(p.Id, p.Name, p.Price, p.Quantity, p.Description, p.Seller_ID));
                }

                index++;
            }

            Session["sellProductList"] = SellingProductList;
            Session["title"] = title.Text;
            Response.Redirect("~/Broadcaster/BroadcastInfo.aspx");
        }

        protected void broadcastBtn_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                liveRoom lr;
                string roomID;
                do
                {
                    roomID = Token();
                    lr = db.liveRooms.SingleOrDefault(x => x.id == roomID);
                } while (lr != null);

                lr = new liveRoom
                {
                    id = roomID,
                    Title = title.Text,
                    seller_Id = Session["id"].ToString()
                };

                db.liveRooms.InsertOnSubmit(lr);
                var path = MapPath("~/Broadcaster/img/");
                var img = new SimpleImage(displayImg.FileContent);
                img.LowQuality();
                img.SaveAs(path + roomID + ".jpg");

                List<liveProduct> lp = new List<liveProduct>();
                foreach (var p in SellingProductList)
                {
                    lp.Add(new liveProduct { roomId = roomID, product_Id = p.id});
                }
                db.liveProducts.InsertAllOnSubmit(lp);
                db.SubmitChanges();
                Response.Redirect("Broadcast.aspx?roomid=" + roomID);
            }
        }

        protected void titleValidation_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (!string.IsNullOrEmpty(args.Value))
            {
                if (args.Value.Length > 50)
                {

                    titleValidation.ErrorMessage = "Max 50 characters";
                    args.IsValid = false;
                }
            }
            else
            {
                titleValidation.ErrorMessage = "Title cannot be empty";
                args.IsValid = false;
            }
            
        }

        protected void itemProduct_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (SellingProductList != null)
            {
                if (SellingProductList.Count > 10)
                {
                    itemProduct.ErrorMessage = "Only allow maximum 10 products";
                    args.IsValid = false;
                }
            }
            else
            {
                itemProduct.ErrorMessage = "No product selected";
                args.IsValid = false;
            }
        }

        private string Token()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[16];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(stringChars);
        }

        protected void imgValidation_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var pattern = new Regex(@".+\.(jpg|png|jpeg)$", RegexOptions.IgnoreCase);

            if (string.IsNullOrEmpty(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "No picture chosen";
            }
            else if (!pattern.IsMatch(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "Only JPG and PNG are allowed for [Photo]";
            }
        }
    }
}