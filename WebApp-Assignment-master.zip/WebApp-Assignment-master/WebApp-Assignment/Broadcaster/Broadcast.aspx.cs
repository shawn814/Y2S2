﻿using System;
using System.Linq;
using System.Web.UI;

namespace WebApp_Assignment.Broadcaster
{
    public partial class Broadcast : Page
    {
        ConnetDataContext db = new ConnetDataContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Session["role"] as string) && Session["role"].ToString() == "Seller")
            {
                string roomID = Request.QueryString["roomid"];

                if (!string.IsNullOrEmpty(roomID))
                {
                    liveRoom lr = db.liveRooms.FirstOrDefault(x => x.id == roomID);

                    if(lr != null)
                    {
                        roomid.Value = roomID;
                        sellerField.Value = Session["name"].ToString();
                    }
                    else
                    {
                        Response.Redirect("~/Error.aspx?errmsg=No room found");
                    }
                }
                else
                {
                    Response.Redirect("~/Error.aspx?errmsg=No room found");
                }
            }
            else
            {
                Response.Redirect(string.IsNullOrEmpty(Session["role"] as string)
                    ? "~/Error.aspx?errmsg=Login seller account to Broadcast"
                    : "~/Error.aspx?errmsg=You dont have permission to Broadcast");
            }
        }
    }
}