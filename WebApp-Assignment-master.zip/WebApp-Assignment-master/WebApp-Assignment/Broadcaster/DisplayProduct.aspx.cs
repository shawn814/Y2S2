﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp_Assignment
{
    public partial class DisplayProduct : Page
    {
        private readonly ConnetDataContext db = new ConnetDataContext();
        private string id = "", role = "", sId = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Session["id"] as string)||!string.IsNullOrEmpty(Session["role"] as string))
            {
                id = Session["id"].ToString();
                role = Session["role"].ToString();
                sId = Request.QueryString["sId"];
                var productId = Request.QueryString["productId"];
                var p = db.Products.SingleOrDefault(
                    a => a.Id == productId);
                productImage.ImageUrl = "~/Product_Image/" + productId + ".jpg";
                lbName.Text = p.Name;
                lbDescription.Text = p.Description;
                lbPrice.Text = p.Price.ToString();
                lbLeftQuantity.Text = "*The stock still left " + p.Quantity;
            }
            else
            {
                Response.Redirect("~/Error.aspx?errmsg=Login to view product");
            }
        }

        protected void addToCart_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                var productId = Request.QueryString["productId"];
                var p = db.Products.SingleOrDefault(
                    a => a.Id == productId);
                var quantity = Convert.ToInt32(txtQuantity.Text);
                var maxQuantity = p.Quantity;

                if (quantity > maxQuantity)
                {
                    cvQuantity.IsValid = false;
                }
                else
                {
                    cvQuantity.IsValid = true;
                    var repeat = db.Carts.SingleOrDefault(
                        a => a.Buyer_Id == id && a.Product_ID == productId);
                    if (repeat == null)
                    {
                        var c = new Cart
                        {
                            Buyer_Id = id,
                            Product_ID = productId,
                            Cart_Quantity = quantity
                        };
                        db.Carts.InsertOnSubmit(c);
                        db.SubmitChanges();
                        Response.Redirect("~/Broadcaster/DisplayProduct.aspx?sId=" + sId + "&productId=" + productId);
                    }
                    else
                    {
                        repeat.Cart_Quantity = quantity;
                        db.SubmitChanges();
                        Response.Redirect("~/Broadcaster/DisplayProduct.aspx?sId=" + sId + "&productId=" + productId);
                    }
                }
            }
        }

        protected void back_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Broadcaster/Channel.aspx?sId=" + sId);
        }

        protected void cvQuantity_ServerValidate(object source, ServerValidateEventArgs args)
        {
            int p;
            if (string.IsNullOrEmpty(txtQuantity.Text))
            {
                args.IsValid = false;
                cvQuantity.ErrorMessage = "Quantity is empty";
            }
            else if (!int.TryParse(txtQuantity.Text, out p))
            {
                args.IsValid = false;
                cvQuantity.ErrorMessage = "Please enter integer";
            }
        }
    }
}