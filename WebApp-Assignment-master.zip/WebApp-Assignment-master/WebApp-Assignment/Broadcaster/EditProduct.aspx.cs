﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using Helpers;

namespace WebApp_Assignment.Broadcaster
{
    public partial class EditProduct : Page
    {
        private readonly ConnetDataContext d = new ConnetDataContext();
        private string productId, sellerId;

        protected void Page_Load(object sender, EventArgs e)
        {
            sellerId = Request.QueryString["sId"];
            productId = Request.QueryString["productId"];
            if (!string.IsNullOrEmpty(Session["role"] as string) && Session["role"].ToString() == "Seller")
            {
                if (!IsPostBack)
                {
                    var p = d.Products.SingleOrDefault(
                        s => s.Id == productId && s.Seller_ID == sellerId);
                    if (p != null)
                    {
                        txtName.Text = p.Name;
                        txtPrice.Text = p.Price.ToString();
                        txtDescription.Text = p.Description;
                        txtQuantity.Text = p.Quantity.ToString();
                        productImage.ImageUrl = "~/Product_Image/" + productId + ".jpg";
                    }
                    else
                    {
                        Response.Redirect("~/Home.aspx");
                    }
                }
            }
            else
            {
                Response.Redirect(string.IsNullOrEmpty(Session["role"] as string)
                    ? "~/Error.aspx?errmsg=Login seller account to edit product"
                    : "~/Error.aspx?errmsg=You dont have permission to edit product");
            }
        }

        protected void updateP_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                var p = d.Products.SingleOrDefault(a => a.Id == productId);
                if (p != null)
                {
                    var name = txtName.Text;
                    var price = Convert.ToDecimal(txtPrice.Text);
                    var quantity = Convert.ToInt32(txtQuantity.Text);
                    var description = txtDescription.Text;
                    p.Name = name;
                    p.Price = price;
                    p.Description = description;
                    p.Quantity = quantity;
                    if (fuImage.HasFile)
                    {
                        var path = MapPath("~/Product_Image/");
                        File.Delete(path + productId + ".jpg");
                        var img = new SimpleImage(fuImage.FileContent);
                        img.Square();
                        img.Resize(150);
                        img.SaveAs(path + productId + ".jpg");
                    }
                }

                d.SubmitChanges();
                Response.Redirect("~/Broadcaster/EditProduct.aspx?sId=" + sellerId + "&productId=" + productId);
            }
        }

        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Broadcaster/Channel.aspx?sId=" + sellerId);
        }

        protected void deleteP_Click(object sender, EventArgs e)
        {
            var p = d.Products.SingleOrDefault(o => o.Id == productId);
            if (p != null)
            {
                var path = MapPath("~/Product_Image/");
                File.Delete(path + productId + ".jpg");
                d.Products.DeleteOnSubmit(p);
                try
                {
                    d.SubmitChanges();
                    Response.Redirect("~/Broadcaster/Channel.aspx?sId=" + sellerId);
                }
                catch (System.Exception)
                {
                    lblError.Text = "The product cannot be deleted";
                }
            }

            //Do try catch because the thing which have the order will nt cant be deleted
            
        }

        protected void cvName_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errName = productValidation.pName(args.Value);
            if (!string.IsNullOrEmpty(errName))
            {
                cvName.ErrorMessage = errName;
                args.IsValid = false;
            }
        }

        protected void cvQuantity_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errQuantity = productValidation.pQuantity(args.Value);
            if (!string.IsNullOrEmpty(errQuantity))
            {
                cvQuantity.ErrorMessage = errQuantity;
                args.IsValid = false;
            }
        }

        protected void cvDescription_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errDesc = productValidation.pDesc(args.Value);
            if (!string.IsNullOrEmpty(errDesc))
            {
                cvDescription.ErrorMessage = errDesc;
                args.IsValid = false;
            }
        }

        protected void cvPrice_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var errPrice = productValidation.pPrice(args.Value);
            if (!string.IsNullOrEmpty(errPrice))
            {
                cvPrice.ErrorMessage = errPrice;
                args.IsValid = false;
            }
        }
        protected void imgValidation_ServerValidate(object source, ServerValidateEventArgs args)
        {
            var pattern = new Regex(@".+\.(jpg|png|jpeg)$", RegexOptions.IgnoreCase);

            if (string.IsNullOrEmpty(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "No picture chosen";
            }
            else if (!pattern.IsMatch(args.Value))
            {
                args.IsValid = false;
                imgValidation.ErrorMessage = "Only JPG and PNG are allowed for [Photo]";
            }
        }
    }
}