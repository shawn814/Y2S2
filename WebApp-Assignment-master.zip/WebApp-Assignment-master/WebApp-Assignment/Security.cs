﻿using System;
using System.Linq;
using System.IO;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.Security;

namespace WebApp_Assignment
{
    public class Security
    {
        public static string GetHash(string strPass)
        {
            var binPass = Encoding.Default.GetBytes(strPass);

            var sha = SHA256.Create();
            var binHash = sha.ComputeHash(binPass);
            var strHash = Convert.ToBase64String(binHash);

            return strHash;
        }

        public static void LoginUser(string txtemail, string role, bool rememberMe)
        {
            var ctx = HttpContext.Current;

            var authCookie = FormsAuthentication.GetAuthCookie(txtemail, rememberMe);
            var oldTicket = FormsAuthentication.Decrypt(authCookie.Value);
            var newTicket = new FormsAuthenticationTicket(
                oldTicket.Version,
                oldTicket.Name,
                oldTicket.IssueDate,
                oldTicket.Expiration,
                oldTicket.IsPersistent,
                role
            );
            authCookie.Value = FormsAuthentication.Encrypt(newTicket);
            ctx.Response.Cookies.Add(authCookie);

            var redirectUrl = FormsAuthentication.GetRedirectUrl(txtemail, rememberMe);
            ctx.Response.Redirect(redirectUrl);
        }

        public static void ProcessRoles()
        {
            var ctx = HttpContext.Current;

            if (ctx.User != null &&
                ctx.User.Identity.IsAuthenticated &&
                ctx.User.Identity is FormsIdentity)
            {
                var identity = (FormsIdentity) ctx.User.Identity;
                var roles = identity.Ticket.UserData.Split(',');

                var principal = new GenericPrincipal(identity, roles);
                ctx.User = principal;
                Thread.CurrentPrincipal = principal;
            }
        }

        public static string ParseOutHTML(string htmlContent)
        {
            var parsedContent = string.Empty;
            var tagPattern = new Regex(@"(?<=^|>)[^><]+?(?=<|$)", RegexOptions.IgnoreCase);
            var tagsRemoved = tagPattern.Matches(htmlContent);
            foreach (Match match in tagsRemoved)
                parsedContent += match.Value.Trim() + " ";
            return parsedContent;
        }

        public static string autoId(char type)
        {
            return type + Guid.NewGuid().ToString("N");
        }

        public static string Token()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var stringChars = new char[16];
            var random = new Random();

            for (int i = 0; i < stringChars.Length; i++)
            {
                stringChars[i] = chars[random.Next(chars.Length)];
            }

            return new string(stringChars);
        }

        public static void DeleteBroadcast()
        {
            ConnetDataContext db = new ConnetDataContext();

            liveRoom lr = db.liveRooms.SingleOrDefault(x => x.seller_Id == System.Web.HttpContext.Current.Session["id"].ToString());

            if (lr != null)
            {
                var lp = db.liveProducts.Where(x => x.roomId == lr.id);
                db.liveProducts.DeleteAllOnSubmit(lp);
                db.liveRooms.DeleteOnSubmit(lr);
                db.SubmitChanges();
                var path = HttpContext.Current.Server.MapPath("~/Broadcaster/img/");
                File.Delete(path + lr.id + ".jpg");
            }
        }
    }
}